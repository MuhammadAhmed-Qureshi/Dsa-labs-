
#include<iostream>
#include<stack>
using namespace std;

template<typename T>
class AbstractQueue {
public:
    virtual void enQueue(T value) = 0;
    virtual T deQueue() = 0;
    virtual T front() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;

    virtual ~AbstractQueue() {}
};

template<typename T>
class myQueue : public AbstractQueue<T> {

private:
    T* arr;
    int size;
    int frontIndex, rear;

public:

    myQueue(int s) {
        size = s;
        arr = new T[size];
        frontIndex = -1;
        rear = -1;
    }

    ~myQueue() {
        delete[] arr;
    }

    bool isEmpty() const override {
        return frontIndex == -1;
    }

    bool isFull() const override {
        return rear == size - 1;
    }

    void enQueue(T value) override {
        if (isFull())
            return;

        if (isEmpty())
            frontIndex = 0;

        rear++;
        arr[rear] = value;
    }

    T deQueue() override {
        if (isEmpty())
            return T();

        T value = arr[frontIndex];

        if (frontIndex == rear) {
            frontIndex = -1;
            rear = -1;
        }
        else {
            frontIndex++;
        }

        return value;
    }

    T front() const override {
        return arr[frontIndex];
    }

    void display() const {
        for (int i = frontIndex; i <= rear; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }

    void reverseK(int k) {

        int n = rear - frontIndex + 1;

        if (k <= 1 || k > n)
            return;

        stack<T> s;

        for (int i = 0; i < k; i++) {
            s.push(deQueue());
        }

        while (!s.empty()) {
            enQueue(s.top());
            s.pop();
        }

        for (int i = 0; i < n - k; i++) {
            enQueue(deQueue());
        }
    }
};

int main() {

    myQueue<int> q(5);

    int x, k;

    cout << "Enter 5 elements: ";

    for (int i = 0; i < 5; i++) {
        cin >> x;
        q.enQueue(x);
    }

    cout << "Enter K: ";
    cin >> k;

    cout << "Original Queue: ";
    q.display();

    q.reverseK(k);

    cout << "After Reversing: ";
    q.display();

    return 0;
}
