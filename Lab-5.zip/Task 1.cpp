
#include<iostream>
using namespace std;

template<typename T>
class AbstractQueue {
public:
    virtual void enQueue(T value) = 0;
    virtual T deQueue() = 0;
    virtual T front() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;

    virtual ~AbstractQueue() {}
};

template<typename T>
class myQueue : public AbstractQueue<T> {
private:
    T* arr;
    int size;
    int frontIndex, rear;

public:
    myQueue(int s) {
        size = s;
        arr = new T[size];
        frontIndex = -1;
        rear = -1;
    }

    ~myQueue() {
        delete[] arr;
    }

    bool isEmpty() const override {
        return frontIndex == -1;
    }

    bool isFull() const override {
        return rear == size - 1;
    }

    void enQueue(T value) override {
        if (isFull()) {
            cout << "Queue is Full!" << endl;
            return;
        }

        if (isEmpty())
            frontIndex = 0;

        rear++;
        arr[rear] = value;
    }

    T deQueue() override {
        if (isEmpty()) {
            cout << "Queue is Empty!" << endl;
            return T();
        }

        T value = arr[frontIndex];

        if (frontIndex == rear) {
            frontIndex = -1;
            rear = -1;
        }
        else {
            frontIndex++;
        }

        return value;
    }

    T front() const override {
        if (isEmpty()) {
            cout << "Queue is Empty!" << endl;
            return T();
        }

        return arr[frontIndex];
    }

    void display() const {
        if (isEmpty()) {
            cout << "Queue is Empty!" << endl;
            return;
        }

        for (int i = frontIndex; i <= rear; i++) {
            cout << arr[i] << " ";
        }

        cout << endl;
    }
};

int main() {
    myQueue<int> q(5);

    q.enQueue(10);
    q.enQueue(20);
    q.enQueue(30);

    cout << "Queue: ";
    q.display();

    cout << "Deleted Element: " << q.deQueue() << endl;

    cout << "Queue After Deletion: ";
    q.display();

    cout << "Front Element: " << q.front() << endl;

    return 0;
}
