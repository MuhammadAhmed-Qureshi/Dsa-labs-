
#include<iostream>
#include<stack>
using namespace std;

class Queue {
private:
    stack<int> s1, s2;

public:

    void enQueue(int value) {
        s1.push(value);
    }

    int deQueue() {
        if (s1.empty() && s2.empty()) {
            cout << "Queue is Empty!" << endl;
            return -1;
        }

        if (s2.empty()) {
            while (!s1.empty()) {
                s2.push(s1.top());
                s1.pop();
            }
        }

        int value = s2.top();
        s2.pop();

        return value;
    }

    int front() {

        if (s1.empty() && s2.empty())
            return -1;

        if (s2.empty()) {
            while (!s1.empty()) {
                s2.push(s1.top());
                s1.pop();
            }
        }

        return s2.top();
    }

    void display() {
        stack<int> s3 = s2;

        while (!s3.empty()) {
            cout << s3.top() << " ";
            s3.pop();
        }

        cout << endl;
    }
};

int main() {
    Queue q;

    q.enQueue(10);
    q.enQueue(20);
    q.enQueue(30);

    cout << "Queue: ";
    q.display();

    cout << "Deleted: " << q.deQueue() << endl;

    cout << "Front: " << q.front() << endl;

    return 0;
}
